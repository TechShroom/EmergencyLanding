/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class IMGShaderBinary {

	/**
	 * Accepted by the &lt;binaryformat&gt; parameter of ShaderBinary: 
	 */
	public static final int GL_SGX_BINARY_IMG = 0x8C0A;

	private IMGShaderBinary() {}
}
