/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class APPLETextureMaxLevel {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of TexParameteri, TexParameterf,
	 *  TexParameteriv, TexParameterfv, GetTexParameteriv, and GetTexParameterfv:
	 */
	public static final int GL_TEXTURE_MAX_LEVEL_APPLE = 0x813D;

	private APPLETextureMaxLevel() {}
}
