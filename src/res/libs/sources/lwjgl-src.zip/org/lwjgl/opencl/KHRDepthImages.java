/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRDepthImages {

	/**
	 * cl_channel_order 
	 */
	public static final int CL_DEPTH = 0x10BD;

	private KHRDepthImages() {}
}
