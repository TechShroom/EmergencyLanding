/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTAbgr {

	public static final int GL_ABGR_EXT = 0x8000;

	private EXTAbgr() {}
}
