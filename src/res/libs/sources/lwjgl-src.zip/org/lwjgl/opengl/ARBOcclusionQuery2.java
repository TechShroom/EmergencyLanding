/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBOcclusionQuery2 {

	/**
	 *  Accepted by the &lt;target&gt; parameter of BeginQuery, EndQuery,
	 *  and GetQueryiv:
	 */
	public static final int GL_ANY_SAMPLES_PASSED = 0x8C2F;

	private ARBOcclusionQuery2() {}
}
