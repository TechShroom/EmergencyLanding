/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureType2101010REV {

	/**
	 * Accepted by the &lt;type&gt; parameter of TexImage2D and TexImage3D: 
	 */
	public static final int GL_UNSIGNED_INT_2_10_10_10_REV_EXT = 0x8368;

	private EXTTextureType2101010REV() {}
}
